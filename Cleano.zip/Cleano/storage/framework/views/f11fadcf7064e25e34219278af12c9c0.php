<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Cleaneo')); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('CSS/style.css')); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('CSS/style.css')); ?>"> -->
    <link rel="stylesheet" href="<?php echo e(asset('CSS/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('CSS/font-awesome.css')); ?>">

    <!-- google font  -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="<?php echo e(asset('CSS/font-family.css')); ?>">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>

    <!-- this is the jQUERY cdn link -->
    <link href="<?php echo e(asset('CSS/data-table.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('CSS/databootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('CSS/datatable.css')); ?>">

    <!-- Scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>

<body>

    <div class="Dashboard">
        <div class="container-fluid container-xl px-0">
            <?php if (isset($component)) { $__componentOriginalb29d1326c7956ae2b432ba915593d8a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb29d1326c7956ae2b432ba915593d8a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidemenu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidemenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb29d1326c7956ae2b432ba915593d8a7)): ?>
<?php $attributes = $__attributesOriginalb29d1326c7956ae2b432ba915593d8a7; ?>
<?php unset($__attributesOriginalb29d1326c7956ae2b432ba915593d8a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb29d1326c7956ae2b432ba915593d8a7)): ?>
<?php $component = $__componentOriginalb29d1326c7956ae2b432ba915593d8a7; ?>
<?php unset($__componentOriginalb29d1326c7956ae2b432ba915593d8a7); ?>
<?php endif; ?>
            <div class="Dashboard_header mx-3">

                <?php echo e($slot); ?>

            </div>
        </div>
    </div>



    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>



    <script src="<?php echo e(asset('JS/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/font-awesome.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/main.js')); ?>"></script>

    <script src="<?php echo e(asset('JS/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/datatable.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/databootstrap.js')); ?>"></script>


    <script>
    new DataTable('#example');
    </script>

</body>

</html><?php /**PATH C:\Users\Banipreet Kaur\Desktop\VerveGen\Cleano (3)\Cleano\resources\views/layouts/app.blade.php ENDPATH**/ ?>